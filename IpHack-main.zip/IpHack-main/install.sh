cd $HOME
wget --no-check-certificate "https://github.com/mishakorzik/mishakorzik.menu.io/blob/master/%D0%A1%D0%B5%D1%80%D0%B2%D0%B5%D1%80/iphack.zip?raw=true"
mv 'iphack.zip?raw=true' iphack.zip
unzip iphack.zip
echo 'move the iphack folden to the /site-packages/ folder'
